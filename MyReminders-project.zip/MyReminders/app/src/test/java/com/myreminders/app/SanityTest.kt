package com.myreminders.app

import org.junit.Assert.assertEquals
import org.junit.Test

/** Placeholder that proves the unit-test pipeline runs. Real tests start in Milestone 2. */
class SanityTest {
    @Test
    fun pipelineRuns() {
        assertEquals(4, 2 + 2)
    }
}
