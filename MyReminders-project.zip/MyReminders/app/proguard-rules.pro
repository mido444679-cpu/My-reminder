# Project-specific ProGrard/R8 rules. Room, Hilt and Compose ship consumer rules.
