# My Reminders (تذكيراتي)

Native Android reminder app (Kotlin, Jetpack Compose, Room, Hilt, AlarmManager).
Offline-first, Arabic (primary) and English, light/dark themes.

> **Status: Milestone 1 (project skeleton).** The skeleton has **not been built or tested yet**.
> No APK exists. See "Build status" below.

## Build status (honest report)

| Item | Status |
|---|---|
| Source files written | Yes |
| `./gradlew` build run | **No**. The authoring sandbox cannot reach Gradle/Google Maven hosts |
| Unit tests run | **No** (only a placeholder test exists) |
| APK produced | **No**. It will come from the first GitHub Actions run |

## Architecture

Single Gradle module (`:app`) with strict package boundaries. Splitting into Gradle modules is possible later; it adds build time and complexity without benefit at this size.

```
com.myreminders.app
├── data/            Room (database, entities, DAOs), repository implementations, DataStore settings
├── domain/          Pure Kotlin: models, repository interfaces, use cases, recurrence & snooze logic
│                    (no Android imports, so it is fully unit-testable on the JVM)
├── presentation/    Compose screens, ViewModels (StateFlow), theme, navigation
├── scheduling/      AlarmScheduler (wraps AlarmManager), next-occurrence calculation
├── notifications/   Channels, notification builder, action handling (complete / snooze / open)
├── receivers/       ReminderAlarmReceiver, BootReceiver, TimeChangeReceiver, package-replaced
├── backup/          JSON export/import with validation
└── di/              Hilt modules
```

Key rules:

- **Room is the source of truth.** Alarms are derived state. After reboot, update, or time/zone change, the app reads active reminders from Room and rebuilds alarms.
- **One alarm per reminder.** Only the *next* occurrence is scheduled. Request code and PendingIntent are derived from the reminder's stable ID, so rescheduling replaces rather than duplicates.
- **Domain layer has no Android dependencies**, so recurrence, snooze and filtering logic are JVM unit tests.
- **Unidirectional data flow:** UI → ViewModel → use case → repository → Room; state flows back as `StateFlow`.

## Versions (chosen, not yet verified by a build)

AGP 8.7.3, Kotlin 2.0.21, KSP 2.0.21-1.0.28, Hilt 2.52, Room 2.6.1, Compose BOM 2024.12.01, Gradle 8.14.3,
JDK 17, compileSdk/targetSdk 35, minSdk 26. All in `gradle/libs.versions.toml`.

## Build in the cloud (no computer needed)

1. Push this project to a GitHub repository (the owner authorizes this).
2. In the GitHub mobile app or browser: repo → **Actions** → **Android Build** → **Run workflow**.
3. When it finishes, open the run → **Artifacts** → download **MyReminders-debug-apk** (a zip).
4. Extract the zip on your phone, open the `.apk`, and allow "Install unknown apps" for your file manager or browser when asked.
5. To update, download the newer APK and install over the old one.

Debug builds use the application ID suffix `.debug`, so they install alongside any future release build.

## Release builds

No signing keys are stored in this repo. Release signing will be added in Milestone 10 using GitHub Actions secrets.
